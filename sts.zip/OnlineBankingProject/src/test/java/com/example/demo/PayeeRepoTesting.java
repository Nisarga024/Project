package com.example.demo;

import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Customer;
import com.example.demo.layer2.Payee;
import com.example.demo.layer3.PayeeRepository;

@SpringBootTest
public class PayeeRepoTesting {
	@Autowired
	PayeeRepository payeeRepo;
	
	@Test
	void addPayeeDetails() 			//adding Payee
	{  
		Payee payee=new Payee();
		Customer customer=new Customer();
		
		payee.setPayeeId(200);
		payee.setBnefName("Nisarga");
		payee.setBnefAccNo(58788);
		payee.setNickname("nisarga");
		customer.setCustId(100);
		payee.setCustomer2(customer);
		
		payeeRepo.addPayee(payee);
		System.out.println("....Payee Added!!.....");
			
	}
	
	
	@Test
	void deletePayeeDetails()  // Delete Payee
    {
		payeeRepo.removePayee(2);
        System.out.println("....Removed Successfully!!.....");
    }
	
	
	@Test
	void findSinglePayeeDetails()  //finding single payee By payeeID
	{  
		Payee payee = payeeRepo.findPayee(1);	
		System.out.println("------------------------------");
		System.out.println("Payee id  		 : "+payee.getPayeeId());
		System.out.println("Bnef Account No  : "+payee.getBnefAccNo());
		System.out.println("Bnef Name   	 : "+payee.getBnefName());
		System.out.println("Nick name 		 : "+payee.getNickname());
		System.out.println("cust id   		 : "+payee.getCustomer2().getCustId());
		System.out.println("------------------------------");
	}
	

	@Test
	void findAllPayeeDetails()  //finding all Payee
	{
		Set<Payee> payeeSet = payeeRepo.findAllPayees();
		for(Payee payee :payeeSet)
		{
			System.out.println("............................... ");
			System.out.println("Payee ID            : "+payee.getPayeeId());
			System.out.println("Bnef Name           : "+payee.getBnefName());
			System.out.println("Bnef Account number : "+payee.getBnefAccNo());
			System.out.println("Nick Name           : "+payee.getNickname());
			System.out.println("Cust ID             : "+payee.getCustomer2().getCustId());
			System.out.println("............................... ");
		}
	}
}
