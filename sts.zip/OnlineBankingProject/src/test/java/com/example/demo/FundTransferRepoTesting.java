package com.example.demo;

import java.sql.Date;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Customer;
import com.example.demo.layer2.FundTransfer;
import com.example.demo.layer2.Payee;
import com.example.demo.layer3.FundTransferRepository;

@SpringBootTest
public class FundTransferRepoTesting 
{

	@Autowired
	FundTransferRepository transferRepo;
	
	@Test
	void addFundtransaction()   //adding FundTransfer
	{  
			FundTransfer fundtrans = new FundTransfer();
			Payee payee=new Payee();
			Customer customer=new Customer();
			
			fundtrans.setTransactionId(01);
			fundtrans.setTransactionType("IMPS");
			fundtrans.setAmountTrans(5000);
			String str="2021-05-22"; 			//sys date
			Date date=Date.valueOf(str);
			fundtrans.setTransactionDate(date);
			payee.setPayeeId(200);
			fundtrans.setPayee(payee);
			customer.setCustId(100);
			fundtrans.setCustomer1(customer);
			
			transferRepo.addTransaction(fundtrans);
			System.out.println("....Fund-Transfer Added!!.....");
			
	}
	
	@Test
	void findSingleFundTransfer()   //finding single fund-transfer By TransactionID
	{   
		FundTransfer fundtrans = transferRepo.findTransaction(3);
		System.out.println("------------------------------");
		System.out.println("Transaction ID 	    : "+fundtrans.getTransactionId());
		System.out.println("Amount to transfer	: "+fundtrans.getAmountTrans());
		System.out.println("Transaction Date  	: "+fundtrans.getTransactionDate());
		System.out.println("Transaction Type	: "+fundtrans.getTransactionType());
		System.out.println("Payee ID  			: "+fundtrans.getPayee().getPayeeId());
		System.out.println("Cust ID			 	: "+fundtrans.getCustomer1().getCustId());
		System.out.println("------------------------------");
		
	}
	
	@Test
	void findAllFundTransfer() //finding all fundTransaction
	{
		Set<FundTransfer> fundset = transferRepo.findAllTransactions();
		for(FundTransfer fundtransfer :fundset)
		{
			System.out.println("............................... ");
			System.out.println("Transaaction ID    : "+fundtransfer.getTransactionId());
			System.out.println("Transcation Type   : "+fundtransfer.getTransactionType());
			System.out.println("Ammount Transfer   : "+fundtransfer.getAmountTrans());
			System.out.println("Transaction Date   : "+fundtransfer.getTransactionDate());
			System.out.println("Cust ID            : "+fundtransfer.getCustomer1().getCustId());
			System.out.println("Payee ID           : "+fundtransfer.getPayee().getPayeeId());
			System.out.println("............................... ");		
		}
	}
	

}
