package com.example.demo;

import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Customer;
import com.example.demo.layer2.ForgotPass;
import com.example.demo.layer2.Register;
import com.example.demo.layer3.CustomerRepository;

@SpringBootTest
public class CustomerRepoTesting {
	@Autowired
	CustomerRepository customerRepo;
	

	@Test
	void addCustomer()  //adding customer
	{ 
			Customer customer=new Customer();
			ForgotPass forgotPass=new ForgotPass();
			Register register=new Register();
			
			customer.setCustId(100);
			customer.setAccNumber(21134);
			customer.setIniPassword("naveen1999");
			customer.setMasterBal(50000);
			customer.setAccType("savings");
			customer.setSecurityAns("joesph");
			forgotPass.setSecurityId(11);
			register.setRefNo(1);
			customer.setForgotPass(forgotPass);
			customer.setRegister(register);
			
			customerRepo.addCustomer(customer);
			System.out.println("....Customer Added!!.....");
	}
	
	
	@Test
	void getSingleCustomer()  //finding single customers By CustID
	{ 	
		Customer customer = customerRepo.findCustomers(1);
		
		System.out.println("------------------------------");
		System.out.println("cust id   : "+customer.getCustId());
		System.out.println("acc no    : "+customer.getAccNumber());
		System.out.println("ini pass  : "+customer.getIniPassword());
		System.out.println("bal       : "+customer.getMasterBal());
		System.out.println("acc type  : "+customer.getAccType());
		System.out.println("sec ans   : "+customer.getSecurityAns());
		System.out.println("forgo     : "+customer.getForgotPass().getSecurityId());
		System.out.println("reg       : "+customer.getRegister().getRefNo());
		System.out.println("------------------------------");
	}

	@Test
	void findallCustomer()  //finding all Customer
	{
		Set<Customer> custSet = customerRepo.findAllCustomers();
		for(Customer customer :custSet) 
		{
			System.out.println("............................... ");
			System.out.println("customer id        : "+customer.getCustId());
			System.out.println("Account number     : "+customer.getAccNumber());
			System.out.println("Initial password   : "+customer.getIniPassword());
			System.out.println("Master balance     : "+customer.getMasterBal());
			System.out.println("Account type       : "+customer.getAccType());
			System.out.println("Security ans       : "+customer.getSecurityAns());
			System.out.println("Security ID        : "+customer.getForgotPass().getSecurityId());
			System.out.println("Service Ref.No     : "+customer.getRegister().getRefNo());
			System.out.println("............................... ");
		}
	}
}
