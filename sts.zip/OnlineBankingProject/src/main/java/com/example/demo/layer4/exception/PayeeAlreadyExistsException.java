package com.example.demo.layer4.exception;
@SuppressWarnings("serial")
public class PayeeAlreadyExistsException extends Throwable
{
	public PayeeAlreadyExistsException(String msg) 
	{
		super(msg);
	}

}
