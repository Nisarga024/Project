package com.example.demo.layer4;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.ForgotPass;
import com.example.demo.layer3.ForgotPassRepository;

@Service
public class ForgotPassServiceImpl implements ForgotPassService
{
	@Autowired //injects the dependent beans by matching data type
	ForgotPassRepository forgotRepo;

	@Override
	public ForgotPass findSingleSecurityIdService(int forgotNo) 
	{
		return forgotRepo.findSingleSecurityId(forgotNo);
	}

	@Override
	public Set<ForgotPass> findAllSecurityIdService()
	{
		return forgotRepo.findAllSecurityId();
	
	}

	@Override
	public String removeForgotPasswordIdService(int forgotNo)
	{
		ForgotPass pass =forgotRepo.findSingleSecurityId(forgotNo);
		if(pass!=null)
		{
			forgotRepo.removeForgotPasswordId(pass.getSecurityId());
		}
		return " Deleted successfully";
	}
		
}
