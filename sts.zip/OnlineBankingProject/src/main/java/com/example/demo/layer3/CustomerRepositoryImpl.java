package com.example.demo.layer3;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import com.example.demo.layer2.Customer;


@Repository
public class CustomerRepositoryImpl implements CustomerRepository
{
	@PersistenceContext
	 EntityManager entityManager;//auto injected by spring by reading persistance.xml file
       

	@Transactional 
	public void addCustomer(Customer customerRef)
	{
		entityManager.persist(customerRef);		
	}
	
	@Transactional
	public Customer findCustomers(int customerNo) 
	{
		System.out.println("Finding Customers..... ");
		return entityManager.find(Customer.class,customerNo);
	}
	
	@Transactional
	public Set<Customer> findAllCustomers()
	{
		List<Customer> custlist = new ArrayList<Customer>();
		TypedQuery<Customer> query = entityManager.createNamedQuery("Customer.findAll",Customer.class);
		custlist=query.getResultList();
		Set<Customer> custSet = new HashSet<Customer>(custlist);
		return custSet;
	}
	
	@SuppressWarnings({"unchecked","rawtypes"})
	@Transactional
	public Set<Customer> findCustomerbyServiceNo(int serviceNo) 
	{
		Set<Customer> custSet;
		custSet = new HashSet<Customer>();
		Query query = entityManager.createNativeQuery("Select * from Customers where Ref_no =:myref",Customer.class).setParameter("myref", serviceNo);
		custSet =new HashSet(query.getResultList());
					
		return custSet;
	}

	@Transactional
	public List<Customer> getCustByCustid(int custId, String iniPassword) {
		Query query=entityManager.createQuery("select c from Customer c where CUST_ID=:myCustid and INI_PASSWORD=:myPassword",Customer.class);
		query.setParameter("myCustid",custId);
		query.setParameter("myPassword",iniPassword);
		@SuppressWarnings("unchecked")
		List<Customer> userList=query.getResultList();
		return userList;
	}

	@Transactional
	public Customer balance(Customer masterBal) {
		return entityManager.find(Customer.class,masterBal);
	}

	
}