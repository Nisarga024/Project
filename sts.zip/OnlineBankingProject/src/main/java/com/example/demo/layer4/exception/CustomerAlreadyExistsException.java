package com.example.demo.layer4.exception;
@SuppressWarnings("serial")
public class CustomerAlreadyExistsException  extends Throwable
{
	public CustomerAlreadyExistsException(String msg)
	{
		super(msg);
	}

}
