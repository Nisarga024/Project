package com.example.demo.layer2;


import java.util.Date;


public class RegisterDTO  {
	

	private String aadharNo;

	private Date dob;

	private String email;

	private String fathersName;

	private String fname;

	private String lname;

	private String mname;

	private long mobileNo;

	private String occupation;

	private String perAddress;

	private String resAddress;
	//bi-directional many-to-one association to Customer

	public RegisterDTO() {
		super();
		System.out.println("RegisterDTO Constructor()");
	}



	public String getAadharNo() {
		return this.aadharNo;
	}

	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}

	public Date getDob() {
		return this.dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFathersName() {
		return this.fathersName;
	}

	public void setFathersName(String fathersName) {
		this.fathersName = fathersName;
	}

	public String getFname() {
		return this.fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return this.lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getMname() {
		return this.mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public long getMobileNo() {
		return this.mobileNo;
	}

	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getOccupation() {
		return this.occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getPerAddress() {
		return this.perAddress;
	}

	public void setPerAddress(String perAddress) {
		this.perAddress = perAddress;
	}

	public String getResAddress() {
		return this.resAddress;
	}

	public void setResAddress(String resAddress) {
		this.resAddress = resAddress;
	}



}