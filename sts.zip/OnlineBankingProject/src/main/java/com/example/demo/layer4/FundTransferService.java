package com.example.demo.layer4;

import java.util.Set;

import org.springframework.stereotype.Service;
import com.example.demo.layer2.FundTransfer;
import com.example.demo.layer2.FundTransferDTO;
import com.example.demo.layer4.exception.FundTransferAlreadyExistsException;
import com.example.demo.layer4.exception.FundTransferNotFoundException;
import com.example.demo.layer4.exception.PayeeNotFoundException;

@Service
public interface FundTransferService 
{	
	String addTransactionService(FundTransfer fundtransRef)throws FundTransferAlreadyExistsException;  
	String addTransactionService(FundTransferDTO fundtransRef)throws Exception, PayeeNotFoundException;  
	FundTransfer findTransactionsService(int fundNo)throws FundTransferNotFoundException; 
	Set<FundTransfer> findAllTransactionsService(); 
	Set<FundTransfer> findTransactionByPayeeId(int payeeId);
	Set<FundTransfer> findTransactionByCustId(int custId);
}
