package com.example.demo.layer4.exception;
@SuppressWarnings("serial")
public class FundTransferAlreadyExistsException extends Throwable
{
	public FundTransferAlreadyExistsException(String msg)
	{
		super(msg);
	}

}
