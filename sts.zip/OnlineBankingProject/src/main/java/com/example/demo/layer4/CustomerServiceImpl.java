package com.example.demo.layer4;

import java.util.List;
import java.util.Set;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.demo.layer2.Customer;
import com.example.demo.layer2.CustomerDTO;
import com.example.demo.layer3.CustomerRepository;
import com.example.demo.layer4.exception.CustomerAlreadyExistsException;
import com.example.demo.layer4.exception.CustomerNotFoundException;

@Service
public class CustomerServiceImpl implements CustomerService 
{
	@Autowired //injects the dependent beans by matching data type
	CustomerRepository customerRepo;
	
	
	public Customer athentication(int custId,String iniPassword)throws CustomerNotFoundException
	{	
		String psw;
		Customer cust= customerRepo.findCustomers(custId);
		
		if(cust!=null) 
		{
			psw = cust.getIniPassword();
		}
		else
		{
			throw new CustomerNotFoundException("User Not Found");
		}
		if(!psw.equalsIgnoreCase(iniPassword))
		{
			throw new CustomerNotFoundException("Invalid Password");
		}

		return cust;

	}
	
	@Override
	public String addCustomerService(Customer custRef) throws CustomerAlreadyExistsException
	{
			try 
			{
				customerRepo.addCustomer(custRef);
			} 
			catch (Exception e)
			{
//				e.printStackTrace();
//				throw e;
				throw new CustomerAlreadyExistsException("Customer already exists");
			}
			System.out.println("Customer added successfully");
			return "Customer added successfully";
	}

	@Override
	public Customer findCustomerService(int custNo)throws CustomerNotFoundException 
	{		
		try 
		{
			return customerRepo.findCustomers(custNo);
		} 
		catch (Exception e)
		{
			throw new CustomerNotFoundException("Customer not found");	
		}
	}

	@Override
	public Set<Customer> findAllCustomersService()
	{	
		return customerRepo.findAllCustomers();
	}

	
	@Override
	public Set<Customer> findCustomerbyServiceNo(int serviceNo)
	{
		Set<Customer>custSet=customerRepo.findCustomerbyServiceNo(serviceNo);
		return custSet;
	}
	@Override
	public String addCustomerService(CustomerDTO custRef) throws CustomerAlreadyExistsException 
	{
		try 
			{
				//registerRepo.findRegistration(custRef)
				Customer newCust = new Customer();
				newCust.setCustId(custRef.getCustId());				
				newCust.setAccNumber(custRef.getAccNumber());
				newCust.setAccType(custRef.getAccType());
				newCust.setIniPassword(custRef.getIniPassword());
				newCust.setMasterBal(custRef.getMasterBal());
				newCust.setRegister(custRef.getRegister());	
				  
				customerRepo.addCustomer(newCust);			
			} 
			catch (Exception e) 
			{				
//				e.printStackTrace();
				throw e;
				
			}
			System.out.println("Customer added successfully");
			return "Customer added successfully";
		}

	@Override
	public List<Customer> userValidationService(int custId, String inipassword)
	{
		List<Customer> userList=customerRepo.getCustByCustid(custId, inipassword);
		return userList;
	}
	
	@Override
	public Customer showBalance(Customer masterBal) 
	{
		return customerRepo.balance(masterBal);
	}
	
}
	




