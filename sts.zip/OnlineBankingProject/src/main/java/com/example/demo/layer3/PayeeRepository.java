package com.example.demo.layer3;


import java.util.Set;

import org.springframework.stereotype.Repository;


import com.example.demo.layer2.Payee;

@Repository
public interface PayeeRepository
{
	void addPayee(Payee payeeRef);   
	Payee findPayee(int payeeNo); 
	Set<Payee>findAllPayees(); 
	void removePayee(int payeeNo); 
	Set<Payee> findPayeeByCustId(int custId);
}