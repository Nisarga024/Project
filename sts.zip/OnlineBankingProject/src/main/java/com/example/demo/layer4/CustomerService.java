package com.example.demo.layer4;

import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.Customer;
import com.example.demo.layer2.CustomerDTO;	
import com.example.demo.layer4.exception.CustomerAlreadyExistsException;
import com.example.demo.layer4.exception.CustomerNotFoundException;


@Service
public interface CustomerService 
{
	String addCustomerService(Customer custRef) throws CustomerAlreadyExistsException;
	String addCustomerService(CustomerDTO custRef) throws CustomerAlreadyExistsException;
	Customer findCustomerService(int custNo)throws CustomerNotFoundException ;
	Set<Customer>findAllCustomersService(); 	
	Set<Customer> findCustomerbyServiceNo(int serviceNo);
	List<Customer> userValidationService(int custId,String inipassword);
	Customer showBalance(Customer masterBal);
}