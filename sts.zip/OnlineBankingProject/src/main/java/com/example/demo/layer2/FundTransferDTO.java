package com.example.demo.layer2;



import java.util.Date;


public class FundTransferDTO  {

	private long amountTrans;
	private Date transactionDate;
	private String transactionType;
	private int custId;
	private int payeeId;
	
	public FundTransferDTO() {
		super();
		System.out.println("FundTransfer constructor()");
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public int getPayeeId() {
		return payeeId;
	}

	public void setPayeeId(int payeeId) {
		this.payeeId = payeeId;
	}

	public long getAmountTrans() {
		return this.amountTrans;
	}

	public void setAmountTrans(long amountTrans) {
		this.amountTrans = amountTrans;
	}

	public Date getTransactionDate() {
		return this.transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getTransactionType() {
		return this.transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}


}