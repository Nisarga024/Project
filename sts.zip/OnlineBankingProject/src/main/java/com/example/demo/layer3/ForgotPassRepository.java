package com.example.demo.layer3;

import java.util.Set;
import org.springframework.stereotype.Repository;
import com.example.demo.layer2.ForgotPass;

@Repository
public interface ForgotPassRepository
{

	ForgotPass findSingleSecurityId(int forgotNo);
	Set<ForgotPass> findAllSecurityId();
	void removeForgotPasswordId(int forgotNo); 
}
