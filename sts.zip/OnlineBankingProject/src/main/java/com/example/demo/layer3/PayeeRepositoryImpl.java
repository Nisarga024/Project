package com.example.demo.layer3;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import com.example.demo.layer2.Payee;



@Repository
public class PayeeRepositoryImpl implements PayeeRepository {
	@PersistenceContext
	 EntityManager entityManager;//auto injected by spring by reading 
										//persistance.xml file
	
	@Transactional        //no need of begin transaction and commit rollback
	public void addPayee(Payee payeeRef) 
	{								//usesA
		entityManager.persist(payeeRef);
	}
	
	@Transactional
	public Payee findPayee(int payeeNo)
	{
		System.out.println("Payee repo....NO scope of bussiness logic here...");
		return entityManager.find(Payee.class,payeeNo);		
	}
	
	@Transactional
	public void removePayee(int payeeNo)
	{
		Payee payeeTemp = entityManager.find(Payee.class,payeeNo);
		entityManager.remove(payeeTemp);
	}

	@Transactional
	public Set<Payee> findAllPayees() 
	{

		List<Payee> payeelist = new ArrayList<Payee>();
		TypedQuery<Payee> query = entityManager.createNamedQuery("Payee.findAll",Payee.class);
		payeelist=query.getResultList();
		Set<Payee> payeeSet = new HashSet<Payee>(payeelist);
		return payeeSet;
	}

	@SuppressWarnings({"unchecked","rawtypes"})
	@Transactional
	public Set<Payee> findPayeeByCustId(int custId) 
	{
		Set<Payee> custSet;
		custSet = new HashSet<Payee>();
		Query query = entityManager.createNativeQuery("Select * from Payee where cust_id =:mycust",Payee.class).setParameter("mycust", custId);
		custSet =new HashSet(query.getResultList());
					
		return custSet;
	}

}