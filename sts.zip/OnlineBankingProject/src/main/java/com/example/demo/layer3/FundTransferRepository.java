
package com.example.demo.layer3;



import java.util.Set;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.FundTransfer;
@Repository
public interface FundTransferRepository 
{
	void addTransaction(FundTransfer fundtransRef);   // add/create
	FundTransfer findTransaction(int fundNo);     
	Set<FundTransfer> findAllTransactions(); 
	Set<FundTransfer> findTransactionByCustId(int custId);
	Set<FundTransfer> findTransactionByPayeeId(int payeeId);
	
}