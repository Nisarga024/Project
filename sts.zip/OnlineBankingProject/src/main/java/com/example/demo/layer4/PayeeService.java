package com.example.demo.layer4;

import java.util.Set;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.Payee;
import com.example.demo.layer2.PayeeDTO;
import com.example.demo.layer4.exception.PayeeAlreadyExistsException;
import com.example.demo.layer4.exception.PayeeNotFoundException;

@Service
public interface PayeeService 
{
	String addPayeeService(Payee payeeRef)throws PayeeAlreadyExistsException; 
	String addPayeeService(PayeeDTO payeeRef)throws Exception, PayeeAlreadyExistsException; 
	Payee findPayeeService(int payeeNo)throws PayeeNotFoundException;  
	Set<Payee>findAllPayeesService();
	String removePayeeService(int payeeNo); 
	Set<Payee> findPayeeByCustId(int custId);
}