package com.example.demo.layer2;

public class PayeeDTO
{
	

	private long bnefAccNo;
	private String bnefName;
	private String nickname;
	private int custId;


	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public PayeeDTO() {
		super();
		System.out.println("Payee constructor()");
	}

	public long getBnefAccNo() {
		return this.bnefAccNo;
	}

	public void setBnefAccNo(long bnefAccNo) {
		this.bnefAccNo = bnefAccNo;
	}

	public String getBnefName() {
		return this.bnefName;
	}

	public void setBnefName(String bnefName) {
		this.bnefName = bnefName;
	}

	public String getNickname() {
		return this.nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

}