package com.example.demo.layer2;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.Set;


@Entity
@Table(name="CUSTOMERS")
@NamedQuery(name="Customer.findAll", query="SELECT c FROM Customer c")
public class Customer {
	

	@Id
	@Column(name="CUST_ID")
	private int custId;

	@Column(name="ACC_NUMBER")
	private long accNumber;

	@Column(name="ACC_TYPE")
	private String accType;

	@Column(name="INI_PASSWORD")
	private String iniPassword;

	@Column(name="MASTER_BAL")
	private long masterBal;

	@Column(name="SECURITY_ANS")
	private String securityAns;

	//bi-directional many-to-one association to Forgotpass
	@ManyToOne
	//@MapsId
	@JoinColumn(name="SECURITY_ID")
	private ForgotPass forgotpass;

	//bi-directional many-to-one association to Register
	@ManyToOne
	//@MapsId
	@JoinColumn(name="REF_NO")
	private Register register;
	
	
	

	//bi-directional many-to-one association to Fundtransfer
	@OneToMany(mappedBy="customer1", fetch=FetchType.EAGER)
	private Set<FundTransfer> fundtransfers;

	//bi-directional many-to-one association to Payee
	@OneToMany(mappedBy="customer2", fetch=FetchType.EAGER)
	private Set<Payee> payees;

	public Customer() {
		super();
		System.out.println("Customer constructor()");
	}

	public int getCustId() {
		return this.custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public long getAccNumber() {
		return this.accNumber;
	}

	public void setAccNumber(long accNumber) {
		this.accNumber = accNumber;
	}

	public String getAccType() {
		return this.accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public String getIniPassword() {
		return this.iniPassword;
	}

	public void setIniPassword(String iniPassword) {
		this.iniPassword = iniPassword;
	}

	public long getMasterBal() {
		return this.masterBal;
	}

	public void setMasterBal(long masterBal) {
		this.masterBal = masterBal;
	}

	public String getSecurityAns() {
		return this.securityAns;
	}

	public void setSecurityAns(String securityAns) {
		this.securityAns = securityAns;
	}
	@JsonIgnore
	public ForgotPass getForgotPass() {
		return this.forgotpass;
	}

	public void setForgotPass(ForgotPass forgotpass) {
		this.forgotpass = forgotpass;
	}
	
	@JsonIgnore
	public Register getRegister() {
		return this.register;
	}

	public void setRegister(Register register) {
		this.register = register;
	}

	public Set<FundTransfer> getFundtransfers() {
		return this.fundtransfers;
	}

	public void setFundtransfers(Set<FundTransfer> fundtransfers) {
		this.fundtransfers = fundtransfers;
	}
	public Set<Payee> getPayees() {
		return this.payees;
	}

	public void setPayees(Set<Payee> payees) {
		this.payees = payees;
	}

}