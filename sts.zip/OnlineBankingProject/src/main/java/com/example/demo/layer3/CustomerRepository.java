package com.example.demo.layer3;

import java.util.List;
import java.util.Set;
import org.springframework.stereotype.Repository;
import com.example.demo.layer2.Customer;


@Repository
public interface CustomerRepository
{
	void addCustomer(Customer customerRef);
	Customer findCustomers(int customerNo);
	Set<Customer>findAllCustomers();  
	Set<Customer> findCustomerbyServiceNo(int serviceNo);
	List<Customer> getCustByCustid(int custId,String iniPassword);
	Customer balance(Customer masterBal);
}
