package com.example.demo.layer3;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.layer2.Register;

@Repository
public class RegisterRepositoryImpl implements RegisterRepository
{
	@PersistenceContext
	 EntityManager entityManager;//auto injected by spring by reading persistance.xml file
										
	
	@Transactional		//no need of begin transaction and commit rollback
	public void  addRegistration(Register registerRef) //usesA
	{												
		entityManager.persist(registerRef);
	}
	
	@Transactional
	public Register findRegistration(int register)
	{											
		System.out.println("Registration repo....NO scope of bussiness logic here...");
		return entityManager.find(Register.class,register);
		
	}
	
	@Transactional
	public Set<Register> findRegistration() 
	{
	
		List<Register> list = new ArrayList<Register>();
		TypedQuery<Register> query = entityManager.createNamedQuery("Register.findAll",Register.class);
		list=query.getResultList();
		Set<Register> rSet = new HashSet<Register>(list);
		return rSet;
	}
	
	
}
