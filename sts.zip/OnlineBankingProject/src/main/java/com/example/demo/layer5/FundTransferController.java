package com.example.demo.layer5;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.FundTransfer;
import com.example.demo.layer2.FundTransferDTO;
import com.example.demo.layer4.FundTransferService;
import com.example.demo.layer4.exception.FundTransferNotFoundException;
import com.example.demo.layer4.exception.PayeeNotFoundException;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class FundTransferController {
	
	@Autowired
	FundTransferService fundServ;
	
	@GetMapping(path="/getFund/{myfund}")
	@ResponseBody
	public ResponseEntity<FundTransfer> getFundTransfer(@PathVariable("myfund") Integer fundTransfer)throws FundTransferNotFoundException
	{ 																	
		FundTransfer fundTrans =null;
		
		fundTrans = fundServ.findTransactionsService(fundTransfer);
		if(fundTrans==null)
		{ 
			return ResponseEntity.notFound().build();			
		}
		else
		{
			return ResponseEntity.ok(fundTrans);
		}		
	}
	
	@GetMapping(path="/getFunds")
	@ResponseBody
	Set<FundTransfer>findFundTransferService()
	{
		Set<FundTransfer> regSet = fundServ.findAllTransactionsService();
		return regSet;
		
	}
	
	@PostMapping(path="/addFund")
	public String addFundTransfer(@RequestBody FundTransferDTO fundtrns) throws  PayeeNotFoundException 
	{
		String stmsg = null;
		try 
		{
			stmsg = fundServ.addTransactionService(fundtrns);
		} 
		catch ( PayeeNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		 return stmsg;		
	}
	@GetMapping(path="/gettransid/{mycustId}")
	@ResponseBody
	public Set<FundTransfer> getFundController(@PathVariable("mycustId") int custId) {
		Set<FundTransfer> fundSet=fundServ.findTransactionByCustId(custId);
		return fundSet;
	}
	
	
	@GetMapping(path="/getTransId/{mypayeeId}")
	@ResponseBody
	public Set<FundTransfer> getFundtransferController(@PathVariable("mypayeeId") int payeeId) {
		Set<FundTransfer> fundSet=fundServ.findTransactionByPayeeId(payeeId);
		return fundSet;
	}
}
