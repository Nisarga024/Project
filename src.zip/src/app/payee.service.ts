import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Payee, PayeeDTO } from './payee';

@Injectable({
  providedIn: 'root'
})
export class PayeeService {

  constructor(private myHttp: HttpClient) { }

  addPayeeService(myPay :PayeeDTO){
    return this.myHttp.post("http://localhost:8080/addPay/",myPay,{responseType:'text'}); 
 }


 removePayeeService(myPay:Payee){
   return this.myHttp.delete("http://localhost:8080/deletePay/"+myPay.payeeId,{responseType:'text'});
 }
 
 
findAllPayeeService():Observable<Payee[]>
 {
  alert("All available Payee");
  return this.myHttp.get<Payee[]>("http://localhost:8080/getPays");
}
}
