import { Component, OnInit } from '@angular/core';
import { CustomerDTO } from '../customer';
import { FundTransfer, FundTransferDTO } from '../fundtransfer';
import { FundtransferService } from '../fundtransfer.service';
import { Login } from '../login';
import { PayeeDTO } from '../payee';

@Component({
  selector: 'app-fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.css']
})
export class FundTransferComponent implements OnInit {
  currentUser: any;
  mydata: any;
  myPay: any;

  constructor(private css:FundtransferService) { }

  ngOnInit(): void {
    this.mydata=sessionStorage.getItem("userFromPage");
    this.currentUser=JSON.parse(this.mydata);
  }
 



  myuserinfo: any | undefined;
myTrans:FundTransferDTO=new FundTransferDTO();   
loginDetail: Login =new Login();
mycust :CustomerDTO =new CustomerDTO();
mypay:PayeeDTO=new PayeeDTO();

addTrans(){
  this.myuserinfo = sessionStorage.getItem("userFromPage");
  this.loginDetail = JSON.parse(this.myuserinfo);
 this.myTrans.custId=this.loginDetail.custId;
 this.myTrans.payeeId=this.mycust.payeeId;
  this.css.addTransactionService(this.myTrans).subscribe((data: string) => {
      if(data != null) {  // SUBSSCRIBE THE ADD ALSO
         
      if(confirm("Are you Sure?"))  {
          alert("Fund Transfered successfully");
        }   // prompt("do yu want");
      //    this.router.navigate(["/register/login"]); //IGNORE THIS ROUTING
      }
  }, (err) => {
      alert("something went wrong");
      console.log(err);
  })
}
}
