import { Component, OnInit } from '@angular/core';
import { Login } from '../login';
import { Payee, PayeeDTO } from '../payee';
import { PayeeService } from '../payee.service';

@Component({
  selector: 'app-all-payee',
  templateUrl: './all-payee.component.html',
  styleUrls: ['./all-payee.component.css']
})
export class AllPayeeComponent implements OnInit {





constructor(private payServ:PayeeService) { }

  ngOnInit(): void {
  }

  myPay:PayeeDTO=new PayeeDTO; 
  myuserinfo: any | undefined;
  
  loginDetail: Login =new Login();
  temp: Payee[] | undefined ;
  findAllPay()
  {
    this.myuserinfo = sessionStorage.getItem("userFromPage");
    this.loginDetail = JSON.parse(this.myuserinfo);
   this.myPay.custId=this.loginDetail.custId;
    this.payServ.findAllPayeeService().subscribe((data:Payee[])=>{
    // if(data!=null)
    // {
        this.temp=data;
        console.log(data);
        sessionStorage.setItem("get all Payee",JSON.stringify(data)); // storing this on browser session
    
  }, (err) => {
      console.log(err);
  });
  }}