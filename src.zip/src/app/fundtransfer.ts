import { Customer, CustomerDTO } from "./customer";
import { Payee, PayeeDTO } from "./payee";


export class FundTransfer
{
    transactionId:number | undefined;
	amountTrans:number | undefined;
    transactionDate:Date | undefined;
    transactionType:string | undefined;
    customer1:Customer| undefined;
    payee:Payee | undefined;
    
}

export class FundTransferDTO
{
    transactionId:number | undefined;
	amountTrans:number | undefined;
    transactionDate:Date | undefined;
    transactionType:string | undefined;
   // CUST_ID:CustomerDTO | undefined;
   // PAYEE_ID:PayeeDTO | undefined;
   custId:number=0;
   payeeId:number=0;
}