import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { register, registerDTO } from '../register';
import { RegisterService } from '../register.service';



@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  router: any;

   constructor(private css: RegisterService) { }
    ngOnInit():void { }

myReg:registerDTO=new registerDTO(); 
addRegister(){
  this.css.addRegistrationService(this.myReg).subscribe((data: string) => {
      if(data != null) {  // SUBSSCRIBE THE ADD ALSO 
          alert("Registration is successful");
      //    this.router.navigate(["/register/login"]); //IGNORE THIS ROUTING
      }
  }, (err) => {
      alert("something went wrong");
      console.log(err);
  })
}

}
