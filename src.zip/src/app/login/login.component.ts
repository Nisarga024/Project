import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { Login } from '../login';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  // existingUser: Login
  // constructor(public auth: LoginService) {
  //    this.existingUser = new Login()
  // }
  // signIn(signInForm:any){
  //   this.auth.signIn(this.existingUser)
  // }

  // ngOnInit(): void {
  // }
// username:string | undefined ;
// password:string | undefined ;



  constructor(private router:Router ,private ccs:LoginService) {   
   }
  
  ngOnInit(): void {
  }
//   logIn() :void {
//     if(this.username =="hello" && this.password =="123")
//     {
//     this.router.navigate(["dashboard"]);
//     }
//     else{
//   alert("invalid");
//     }
// }
userFromPage: Login= new Login();
  currentUser: Login= new Login();
  loginStatus: boolean=false;


  userValdation(userFromPage:Login){
    // alert(userFromPage.custId);
    // alert(userFromPage.iniPassword);
 
    this.ccs.userValdationService(userFromPage).subscribe((data:any)=>{
     this.currentUser=data;
     if(this.currentUser==null)
      {
        alert('Incorrect login details'); 
        this.loginStatus=false;
      //  sessionStorage.setItem("loginInfo",JSON.stringify(this.loginStatus));
      this.router.navigate(["login"]);
      }
      else{
        alert('login success');
        
        this.loginStatus=true;
        sessionStorage.setItem("userFromPage",JSON.stringify(this.userFromPage));
       // sessionStorage.setItem("currentUserDetails",JSON.stringify(data));
        this.router.navigate(["dashboard"]);
      }
      })
  }

}
