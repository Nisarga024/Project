import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Customer, CustomerDTO } from './customer';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(private myHttp: HttpClient) { }
  
    addCustomerService(custRef :CustomerDTO)
    {
      return this.myHttp.post("http://localhost:8080/addCust/",custRef,{responseType:'text'}); 
   }
}
