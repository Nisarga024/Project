import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { Login } from '../login';
import { register, registerDTO } from '../register';
import { RegisterService } from '../register.service';

@Component({
  selector: 'app-account-details',
  templateUrl: './account-details.component.html',
  styleUrls: ['./account-details.component.css']
})
export class AccountDetailsComponent implements OnInit {

//   constructor(private resServ:RegisterService) { }

//   ngOnInit(): void {
//   }

//   temp: register | undefined ;
//   findReg(regNo :number)
//   {
//     this.resServ.findRegisterService(regNo).subscribe((data:register)=>{
//     // if(data!=null)
//     // {
//         this.temp=data;
//         console.log(data);
//         sessionStorage.setItem("get all registration",JSON.stringify(data)); // storing this on browser session
    
//   }, (err) => {
//       console.log(err);
//   });
//     // else{
//     //     alert("unable to fetch");
// }

refNo=0;
 reg: register | undefined ;

constructor(private resServ:RegisterService) { }

ngOnInit(): void {
}
myuserinfo: any | undefined;

loginDetail: Login =new Login();
temp: registerDTO= new registerDTO();
cust:Customer =new Customer();

findReg(refNo:number)
{
  this.myuserinfo = sessionStorage.getItem("userFromPage");
  this.loginDetail = JSON.parse(this.myuserinfo);
 this.cust.custId=this.loginDetail.custId;
  this.resServ.findRegisterService(refNo).subscribe((data)=>{
  // if(data!=null)
  // {
      this.temp=data;
      console.log(data);
      sessionStorage.setItem("get all registration",JSON.stringify(data)); // storing this on browser session
  
}, (err) => {
    console.log(err);
});
  // else{
  //     alert("unable to fetch");
}
}
