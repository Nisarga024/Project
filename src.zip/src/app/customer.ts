import { register } from "./register";

export class Customer{
 custId :Number | undefined;
 accNumber:Number | undefined;
 accType:string | undefined;
 iniPassword:string | undefined;
 masterBal:Number | undefined;
 reg:register | undefined;
}

export class CustomerDTO{
    custId :Number | undefined;
    accNumber:Number | undefined;
    accType:string | undefined;
    iniPassword:string | undefined;
    masterBal:Number | undefined;
    // reg:register | undefined;
    refNo:register| undefined;
  payeeId: number=0;
   }