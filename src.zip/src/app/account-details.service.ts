import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { accountdetails } from 'src/accountdetails';

@Injectable({
  providedIn: 'root'
})
export class AccountDetailsService {



  constructor(private myHttp: HttpClient) { }
  findAccountDetailsService(regNo:number):Observable<accountdetails>
  {
    return this.myHttp.get<accountdetails>("http://localhost:8080/getReg/"+regNo);
  }
}
