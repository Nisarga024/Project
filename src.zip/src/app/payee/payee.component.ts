import { Component, OnInit } from '@angular/core';
import { Login } from '../login';
import { Payee, PayeeDTO } from '../payee';
import { PayeeService } from '../payee.service';

@Component({
  selector: 'app-payee',
  templateUrl: './payee.component.html',
  styleUrls: ['./payee.component.css']
})
export class PayeeComponent implements OnInit {
  newPayeeClicked =false;

  payees=[
    { id: 201 ,name:"Sravani",accountno:287478 ,nickname:"sravani",custid:100  }
  ];
  color:any;
  constructor(private pay: PayeeService) { }

  ngOnInit(): void {
  }
  model:any ={};
model2:any={};
// addPayee(){
//   this.payees.push(this.model);
//   this.model={}
// }
// deletePayee(i:any){
//   this.payees.splice(i);
// console.log(i);
// }
myValue:any;

UpdatePayee(){
  let editPayeeInfo=this.myValue;
  for(let i=0;i<this.payees.length;i++)
  {
    if(i==editPayeeInfo){
      this.payees[i]=this.model2;
      this.model2={}
    }
  }
}
addNewPayeeBtn(){
this.newPayeeClicked=!this.newPayeeClicked;

}

  
changeColorOne(){
  this.color =!this.color;
  if(this.color){
    return '#ffffff';
  }else{
    return '#f6f6f6';
  }
}
myPay:PayeeDTO=new PayeeDTO(); 
myuserinfo: any | undefined;

loginDetail: Login =new Login();

addPayee(){
  this.myuserinfo = sessionStorage.getItem("userFromPage");
  this.loginDetail = JSON.parse(this.myuserinfo);
 this.myPay.custId=this.loginDetail.custId;
  this.pay.addPayeeService(this.myPay).subscribe((data: string) => {
      if(data != null) {  // SUBSSCRIBE THE ADD ALSO 
          alert("Payee Entered successful");
      //    this.router.navigate(["/register/login"]); //IGNORE THIS ROUTING
      }
  }, (err) => {
      alert("something went wrong");
      console.log(err);
  })
}

}
