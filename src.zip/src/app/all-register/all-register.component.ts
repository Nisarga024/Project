import { Component, OnInit } from '@angular/core';
import { Customer, CustomerDTO } from '../customer';
import { CustomerService } from '../customer.service';
import { register } from '../register';
import { RegisterService } from '../register.service';

@Component({
  selector: 'app-all-register',
  templateUrl: './all-register.component.html',
  styleUrls: ['./all-register.component.css']
})
export class AllRegisterComponent implements OnInit {

  constructor(private resServ:RegisterService) { }

  ngOnInit(): void {
  }

  temp: register[] | undefined ;
  findAllReg()
  {
    this.resServ.findAllRegistrationService().subscribe((data:register[])=>{
    // if(data!=null)
    // {
        this.temp=data;
        console.log(data);
        sessionStorage.setItem("get all registration",JSON.stringify(data)); // storing this on browser session
    
  }, (err) => {
      console.log(err);
  });
    // else{
    //     alert("unable to fetch");
}
ShowMe2:boolean=false
toogleTag2()
{
  this.ShowMe2=!this.ShowMe2;
  
}

}

