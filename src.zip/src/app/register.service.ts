import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { register, registerDTO } from './register';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {


    constructor(private myHttp: HttpClient) { }

    addRegistrationService(myReg :registerDTO)
    {
     return this.myHttp.post("http://localhost:8080/addReg/",myReg,{responseType:'text'}); 
  }

  findRegisterService(regNo:number):Observable<registerDTO>
  {
    return this.myHttp.get<registerDTO>("http://localhost:8080/getReg/"+regNo);
  }
  findAllRegistrationService():Observable<register[]>
  {
    alert("Displaying all Registration");
    return this.myHttp.get<register[]>("http://localhost:8080/getRegs");
  }

}