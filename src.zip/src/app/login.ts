export class Login {
    custId: number =0;
    iniPassword: string | undefined

}