import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HomeComponent } from './home/home.component';

import { AccountStatementComponent } from './account-statement/account-statement.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { FormsModule } from '@angular/forms';
import { PayeeComponent } from './payee/payee.component';
import { AccountDetailsComponent } from './account-details/account-details.component';
import { HttpClientModule } from '@angular/common/http';
import { RegisterService } from './register.service';
import { AdminComponent } from './admin/admin.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { AllRegisterComponent } from './all-register/all-register.component';
import { CustomerDetailsComponent } from './customer-details/customer-details.component';

import { PayeeService } from './payee.service';
import { CustomerService } from './customer.service';
import { LoginService } from './login.service';
import { FundtransferService } from './fundtransfer.service';
import { AllPayeeComponent } from './all-payee/all-payee.component';
import { AccountDetailsService } from './account-details.service';

@NgModule({
  declarations: [
    
    AppComponent,
    
    LoginComponent,
    RegisterComponent,
    DashboardComponent,
    HomeComponent,
    AccountStatementComponent,
    ForgotPasswordComponent,
    FundTransferComponent,
    AboutUsComponent,
    PayeeComponent,
    AccountDetailsComponent,
    AdminComponent,
    AdminDashboardComponent,
    AllRegisterComponent,
    CustomerDetailsComponent,
    AllPayeeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [RegisterService,CustomerService,PayeeService,LoginService,FundtransferService,AccountDetailsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
