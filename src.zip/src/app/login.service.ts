import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Login } from './login';


@Injectable({
  providedIn: 'root'
})
export class LoginService {


  constructor(private myHttp: HttpClient) { }

  userValdationService(loginDetails: Login):Observable<any>{

    return this.myHttp.post("http://localhost:8080/login",loginDetails);
  
  }
}