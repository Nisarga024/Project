import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Customer } from './customer';
import { FundTransfer, FundTransferDTO } from './fundtransfer';
import { Payee } from './payee';

@Injectable({
  providedIn: 'root'
})
export class FundtransferService {

  constructor(private myHttp: HttpClient) { }

  addTransactionService(fundtransRef:FundTransferDTO){
    return this.myHttp.post("http://localhost:8080/addFund/",fundtransRef,{responseType:'text'});
  }
  findTransactionService(fundNo:number):Observable<any>{
    return this.myHttp.get<FundTransfer>("http://localhost:8080/getFund/"+fundNo);
  }
  findAllTransactionsService():Observable<any>{
    return this.myHttp.get<FundTransfer>("http://localhost:8080/getFunds");
  }
  findTransactionByCustIdService(custId:Customer):Observable<any>{
    return this.myHttp.get<FundTransfer>("http://localhost:8080/gettransId/"+custId);
  }
  findTransactionByPayeeIdService(payeeId:Payee):Observable<any>{
    return this.myHttp.get<FundTransfer>("http://localhost:8080/getTransId/"+payeeId);
  }
}

